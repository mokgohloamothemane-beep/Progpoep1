/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.progpoep1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author mokgo
 */
public class Quickchat{
    static Scanner input = new Scanner(System.in);
    		static String username="      ";
	    	static String password="";
			static String cellNum="";

    public static void main(String[] args) {
        System.out.println("=====registration====");

		//USERNAME

		final int USERNAME_MAX =5;
		while(username.length() > USERNAME_MAX || !username.contains("_")){
		System.out.println("Enter username: ");
		String username = input.nextLine();
		    if(username.length() == USERNAME_MAX){
		    System.out.println("the username that was entered is valid as it is properly formatted");
		}
		else if(username.length() <= USERNAME_MAX || !username.contains("_")){
		    System.out.println("the username that was entered is invalid making the capturing process unsuccessful");
		}

		final int PASSWORD_MIN = 8;
		String password = "";
		do {
			System.out.println("Enter your password: ");
			password = input.nextLine();

			if(password.length() < PASSWORD_MIN) {
				System.out.println("The password that was entered is invalid as it is not properly formatted");

			}
		}  while(password.length() <PASSWORD_MIN || !password.matches(".*[A-Z].*") || !password.matches(".*\\d.*") || !password.matches(".*[^a-zA-Z0-9 ].*"));
		System.out.println("The password that was entered is valid making the capturing process successful");

		final int CELL_LENGTH =10;
		String cellNum =  "  ";
		do {
			System.out.println("Enter cell number");
			cellNum=input.nextLine();

			if(cellNum.length()<CELL_LENGTH) {
				System.out.println("Cellphone number is invalid as it is not properly formmatted");
			}
		}  while(cellNum.length() !=CELL_LENGTH)  ;
		System.out.println("Cellphone number was correct");

		//response message//

		System.out.println("The provided information was relevant making the account creation proccess a success");
		System.out.println("welcome ");

		signingAuthenticator(args);
}
	}

	public static void signingAuthenticator(String[]args) {
		String inputUsername;
		String inputPassword;
		String inputCellNum;
		
		System.out.println("====Login====");
		
		System.out.println("Enter username");
		inputUsername = input.nextLine();

		System.out.println("Enter password");
		inputPassword = input.nextLine();

		System.out.println("Enter cell number");
		inputCellNum = input.nextLine();

		//username methods//

		if(username.equals(inputUsername)) {
			System.out.println("Username is correct");

		} else {
			System.out.println("Username that was entered is invalid as it is not properly formatted");
		}
		//password methods//

		if(inputPassword.equals(password)) {
			System.out.println("The password that was entered is valid making the capturing process successful");

		} else {
			System.out.println("the entered password must be atleast 8 characters for capturing to proceed");
		}


		//cellphone methods//

		if (inputCellNum.equals(cellNum)) {
			System.out.println("Cellphone was correct ");
		} else {
			System.out.println("the entered cellNum is non existent in the SA format");
		}
		System.out.println("username:"+username);
		System.out.println("cellNum:"+cellNum);
		System.out.println("password:"+ password + "*");
	}
        
        public static boolean checkUsername(String username) {
    return username.length() <= 5 && username.contains("_");
}

public static boolean checkPassword(String password) {
    return password.length() >= 8 &&
           password.matches(".*[A-Z].*") &
           password.matches(".*\\d.*") &&
           password.matches(".*[^a-zA-Z0-9].*");
}

public static boolean checkCellNumber(String cellNum) {
    return cellNum.matches("0\\d{9}");
}

    public boolean checkUserName(String k_1) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    
    }

}

//part 2 :


class QuickchatMenu{
     
    static ArrayList<Message>messages = new ArrayList<>();
    static int idCounter = 1;

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int choice;
		
		do{
		    System.out.println("----Quickchat Menu----");
                    System.out.println("Enter the number of message you want to send");
                    System.out.println("Choose an option.");
		    System.out.println("1.Create a Message.");		   
		    System.out.println("2.Read all messages.");
		    System.out.println("3.delete all messages.");
		    System.out.println("4.Exit.");
		    
		     choice = input.nextInt();
		     input.nextLine();
		     
		     switch (choice){
		         case 1 : 
		             createMessage(input);
		             break;
		             
		             case 2 : 
		                 readMessages();
		                 break;
		                 
		                 case 3 :
		                     deleteMessage(input);
		                     break;
		                     
		                     case 4 :
		                         System.out.println("Goodbye!");
		                         break;
		                         
		                         default:
		                         System.out.println("Invalid option ");
		     }
		     
                    }while(choice != 4);
                input.close();
	}
	//Create
	public static void createMessage(Scanner input ){
            
	    System.out.println("Enter MessageID : ");
	    int id = input.nextInt();
	    input .nextLine();
	    
	    System.out.println("Enter Recipient(+1234..) : ");
	    String recipient = input.nextLine();
	    
	   System.out.println("Enter Message content : ");
	    String content = input.nextLine();
	    
	    if(recipient.startsWith("+") && recipient.length()<=13){
	        Message msg = new Message(id,recipient,content);
	        messages.add(msg);
	        
	        System.out.println("Message added successfully");
	    }else{
	        System.out.println("Invalid Recipient!must start with + and be 13 chars ");
	    }
	}
	
	// read all 
	public static void readMessages(){
	    if(messages.isEmpty()){
	        System.out.println("no message was found ");
	        return ;
	    }
	    System.out.println("----all messages----");
	    
	    for (Message msg : messages ){
	        System.out.println(msg);
	    }
	}
	
	// delete 
	public static void deleteMessage(Scanner input){
	    if(messages.isEmpty()){
	        System.out.println("no message to delete ");
	        return;
	    }
	    
	    System.out.println("Enter MessageID to delete");
	    int id = input.nextInt();
	    
	    boolean  found = false ;
	    
	    for(int i = 0 ;i < messages.size(); i++){
	        if (messages.get(i).id==id ){
	            messages.remove(i);
	            
	   System.out.println("Message deleted .");
                  found =true;
                  break;
	        }
	    }
	}
	
	//Message class
	static class Message{
	    
	    int id ;
	    String recipient;
	    String content;
	    
	    public Message(int id,String Recipient,String content){
	        this.id = id;
	        this.recipient = Recipient;
	        this.content = content;
	    }
	}

    }


	    
	

    
